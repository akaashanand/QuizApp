package com.example.quizapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity<index> extends AppCompatActivity {
    private Button yes,no;
    private TextView questions;
    private TextView question_attempted;
    private TextView marks;
    private String[] que={"C programs are converted into machine language with the help of a program called Editor","Spaces and commas are allowed in a variable name","The maximum value that an integer constant can have varies from one compiler to another","A real constant in C can be expressed in both Fractional and Exponential forms","Only character or integer can be used in switch statement"};
    private boolean[] ans={false,false,true,true,false};
    private int count=0;
    private int index= 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        yes=findViewById(R.id.button1);
        no=findViewById(R.id.button2);
        questions=findViewById(R.id.questions);
        question_attempted=findViewById(R.id.question_attempted);
        marks=findViewById(R.id.score);
        questions.setText(que[index]);
        yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (index <= que.length -1) {
                    if (ans[index]) {
                        count++;
                        marks.setText("Score: "+count+"/"+que.length);
                    }
                    index++;
                    question_attempted.setText("Question Attempted: "+index+"/"+ans.length);
                    if (index <= que.length -1) {
                        questions.setText(que[index]);
                    }
                    else {
                        Toast.makeText(MainActivity.this, "Your score is: " + count, Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(MainActivity.this, "Restart the app to play again!!", Toast.LENGTH_SHORT).show();
                }
            }
        });
        no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (index <= que.length -1) {
                    if (ans[index] == false) {
                        count++;
                        marks.setText("Score: "+count+"/"+que.length);
                    }
                    index++;
                    question_attempted.setText("Question Attempted: "+index+"/"+ans.length);
                    if(index <= que.length-1 ) {

                        questions.setText(que[index]);
                    }
                    else{
                        Toast.makeText(MainActivity.this, "Your score is: " + count, Toast.LENGTH_SHORT).show();
                    }
                }
                else{
                    Toast.makeText(MainActivity.this, "Restart the app to play again!!", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
